//
//  WeicyCommonProjectCustom.h
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/1.
//

#ifndef WeicyCommonProjectCustom_h
#define WeicyCommonProjectCustom_h

#import "WeicyCommon.h"

#pragma mark - ////////////////////////////// 项目需要自定义的统一设置 //////////////////////////////

#pragma mark ********** 1.颜色 ************
#define THEME_COLOR             [UIColor systemOrangeColor]
#define VIEW_BG_COLOR           [UIColor systemGray3Color]
#define TabBar_Selected_Color   THEME_COLOR
#define TabBar_Normal_Color     [UIColor systemGray2Color]
#define TabBar_SepLine_Color    [UIColor separatorColor]
#define TabBar_Background_Color Navi_Background_Color
#define NaviBar_Title_Color     [UIColor labelColor]
#define Navi_Background_Color   [UIColor weicy_colorWithLightColor:[UIColor whiteColor] darkColor:[UIColor grayColor]]
#define WEB_PROGRESS_COLOR      THEME_COLOR

#define Fund_UP_Color           [UIColor systemRedColor]
#define Fund_Down_Color         [UIColor systemGreenColor]
#define Fund_Text_Color         [UIColor weicy_colorWithLightColor:[UIColor blackColor] darkColor:[UIColor whiteColor]]
#define Fund_Code_Text_Color    [UIColor systemTealColor]
#define Fund_Code_Background_Color    THEME_COLOR

#pragma mark ********** 2.字体 ************
#define TabBar_Normal_Font        RegularFont(12)
#define TabBar_Selected_Font      MediumFont(12)
#define NaviBar_Font             MediumFont(18)

#define Regular_Smallest_Font     RegularFont(10)
#define Regular_Small_Font        RegularFont(12)
#define Regular_Normal_Font       RegularFont(14)
#define Regular_Large_Font        RegularFont(16)
#define Regular_Largest_Font      RegularFont(18)

#define Medium_Small_Font         MediumFont(12)
#define Medium_Normal_Font        MediumFont(14)
#define Medium_Large_Font         MediumFont(16)
#define Medium_Largest_Font       MediumFont(20)

#define Bold_Small_Font           BoldFont(12)
#define Bold_Normal_Font          BoldFont(14)
#define Bold_LargeFont           BoldFont(16)

#define Semibold_Small_Font       SemiboldFont(12)
#define Semibold_Normal_Font      SemiboldFont(14)
#define Semibold_Large_Font       SemiboldFont(16)

#pragma mark ********** 3.图片 ************
#define NaviBar_Back_Image      [UIImage imageNamed:@"commom_nav_back_black"]
#define NaviBar_Web_Close_Black_Image  [UIImage imageNamed:@"close_black"]
#define PlaceHolder_Image        [UIImage imageNamed:@"place_center_banner_home"]

#pragma mark ********** 4.通知 ************
#define LanguageChangedNotification     @"LanguageChangedNotification"
#define ThemeChangedNotification        @"ThemeChangedNotification"

#endif /* WeicyCommonProjectCustom_h */
