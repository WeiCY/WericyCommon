//
//  WCYRequestEntity.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/5.
//

#import "WCYRequestEntity.h"

@implementation WCYRequestEntity

- (void)setUrlString:(NSString *)urlString {
    if ([urlString containsString:@"http"]) {
        _urlString = urlString;
    } else {
        _urlString = [NSString stringWithFormat:@"%@%@",BASE_URL,urlString];
    }
}

@end
