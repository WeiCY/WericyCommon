//
//  WCYNetworkManager.h
//  WcyFund
//
//  参看BANetManager，但去除了上传下载
// 
//  Created by CityDoWCY on 2021/1/4.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/// 网络状态
typedef enum : NSUInteger {
    WCYNetworkStatusUnknown = 0, // 未知网络
    WCYNetworkStatusNotReachable, // 没有网络
    WCYNetworkStatusReachableViaWWAN, // 移动网络 3G/4G
    WCYNetworkStatusReachableViaWiFi, // wifi
} WCYNetworkStatus;

/// 网络请求类型
typedef enum : NSUInteger {
    WCYHttpRequestTypeGet = 0, // get请求
    WCYHttpRequestTypePost, // post请求
    WCYHttpRequestTypePut, // put请求
    WCYHttpRequestTypeDelete, // delete请求
} WCYHttpRequestType;

/// 设置请求数据
typedef enum : NSUInteger {
    WCYHttpRequestSerializerTypeHTTP,
    WCYHttpRequestSerializerTypeJSON,
} WCYHttpRequestSerializerType;

/// 设置相应数据格式
typedef enum : NSUInteger {
    WCYHttpResponseSerializerTypeJSON,
    WCYHttpResponseSerializerTypeHTTP,
} WCYHttpResponseSerializerType;

/// 实时监测网络状态的block
typedef void(^WCYNetWorkStatusBlock)(WCYNetworkStatus status);
/// 请求成功block
typedef void(^WCYResponseSuccessBlock)(id response);
/// 请求失败的block
typedef void(^WCYResponseFailBlock)(NSError *error);

/*!
 *  方便管理请求任务。执行取消，暂停，继续等任务.
 *  - (void)cancel，取消任务
 *  - (void)suspend，暂停任务
 *  - (void)resume，继续任务
 */
typedef NSURLSessionTask WCYURLSessionTask;

@class WCYRequestEntity;


@interface WCYNetworkManager : NSObject

/// 创建的请求的超时间隔（以秒为单位），此设置为全局统一设置一次即可，默认超时时间间隔为30秒。
@property (nonatomic, assign) NSTimeInterval timeoutInterval;

/// 设置网络请求参数的格式，此设置为全局统一设置一次即可，默认：WCYHttpRequestSerializerTypeHTTP
@property (nonatomic, assign) WCYHttpRequestSerializerType requestSerializer;

/// 设置服务器响应数据格式，此设置为全局统一设置一次即可，默认：WCYHttpResponseSerializerTypeJSON
@property (nonatomic, assign) WCYHttpResponseSerializerType responseSerializer;

/// 自定义请求头：httpHeaderField
@property(nonatomic, strong) NSDictionary *httpHeaderFieldDictionary;

/// 是否开启 log 打印，默认不开启
@property(nonatomic, assign) BOOL isOpenLog;

+ (instancetype)sharedNetworkManager;

/// 网络请求的实例方法 get
/// @param entity 请求信息载体
/// @param successBlock 请求成功的回调
/// @param failureBlock 请求失败的回调
+ (WCYURLSessionTask *)request_GETWithEntity:(WCYRequestEntity *)entity
                                successBlock:(WCYResponseSuccessBlock)successBlock
                                failureBlock:(WCYResponseFailBlock)failureBlock;

/// 网络请求的实例方法 post
/// @param entity 请求信息载体
/// @param successBlock 请求成功的回调
/// @param failureBlock 请求失败的回调
+ (WCYURLSessionTask *)request_POSTWithEntity:(WCYRequestEntity *)entity
                                 successBlock:(WCYResponseSuccessBlock)successBlock
                                 failureBlock:(WCYResponseFailBlock)failureBlock;

/// 网络请求的实例方法 put
/// @param entity 请求信息载体
/// @param successBlock 请求成功的回调
/// @param failureBlock 请求失败的回调
+ (WCYURLSessionTask *)request_PUTWithEntity:(WCYRequestEntity *)entity
                                successBlock:(WCYResponseSuccessBlock)successBlock
                                failureBlock:(WCYResponseFailBlock)failureBlock;

/// 网络请求的实例方法 delete
/// @param entity 请求信息载体
/// @param successBlock 请求成功的回调
/// @param failureBlock 请求失败的回调
+ (WCYURLSessionTask *)request_DELETEWithEntity:(WCYRequestEntity *)entity
                                   successBlock:(WCYResponseSuccessBlock)successBlock
                                   failureBlock:(WCYResponseFailBlock)failureBlock;


#pragma mark - 网络状态监测
/// 开启实时网络状态监测
/// 此方法可多次调用
/// @param networkStatus 网络状态回调
+ (void)wcy_startNetWorkMonitoringWithBlock:(WCYNetWorkStatusBlock)networkStatus;

#pragma mark - 自定义请求头
/// 自定义请求头
/// @param value value
/// @param HTTPHeaderKey key
+ (void)wcy_setValue:(NSString *)value forHTTPHeaderKey:(NSString *)HTTPHeaderKey;

/// 删除所有请求头
+ (void)wcy_clearAuthorizationHeader;

#pragma mark - 取消 Http 请求
/// 取消所有 Http 请求
+ (void)wcy_cancelAllRequest;

/// 取消指定 URL 的 Http 请求
/// @param URL 请求地址
+ (void)wcy_cancelRequestWithURL:(NSString *)URL;

/**
 清空缓存：此方法可能会阻止调用线程，直到文件删除完成。
 */
- (void)wcy_clearAllHttpCache;

@end

NS_ASSUME_NONNULL_END
