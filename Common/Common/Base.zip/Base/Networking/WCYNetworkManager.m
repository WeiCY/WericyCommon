//
//  WCYNetworkManager.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/4.
//

#import "WCYNetworkManager.h"
#import <AFNetworking/AFNetworking.h>
#import <AFNetworking/AFNetworkActivityIndicatorManager.h>

#import "WCYRequestEntity.h"
#import "WCYNetworkCache.h"

#define WCYWeak  __weak __typeof(self) weakSelf = self

static NSMutableArray *tasks;

@interface WCYNetworkManager ()

@property (nonatomic, strong) AFHTTPSessionManager *sessionManager;

@end

@implementation WCYNetworkManager

+ (instancetype)sharedNetworkManager {
    /*! 为单例对象创建的静态实例，置为nil，因为对象的唯一性，必须是static类型 */
    static id sharedNetworkManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedNetworkManager = [[super allocWithZone:NULL] init];
    });
    return sharedNetworkManager;
}

+ (void)initialize {
    [self setupNetManager];
}

+ (void)setupNetManager {
    [WCYNetworkManager sharedNetworkManager].sessionManager = [AFHTTPSessionManager manager];
    
    /*! 设置请求超时时间，默认：30秒 */
    [WCYNetworkManager sharedNetworkManager].timeoutInterval = 30;
    /*! 打开状态栏的等待菊花 */
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    /*! 设置返回数据类型为 json, 分别设置请求以及相应的序列化器 */
    /*!
     根据服务器的设定不同还可以设置：
     json：[AFJSONResponseSerializer serializer]
     http：[AFHTTPResponseSerializer serializer]
     */
//    AFJSONResponseSerializer *response = [AFJSONResponseSerializer serializer];
    AFHTTPResponseSerializer *response = [AFHTTPResponseSerializer serializer];
    /*! 这里是去掉了键值对里空对象的键值 */
    //    response.removesKeysWithNullValues = YES;
    [WCYNetworkManager sharedNetworkManager].sessionManager.responseSerializer = response;
    
    /* 设置请求服务器数类型式为 json */
    /*!
     根据服务器的设定不同还可以设置：
     json：[AFJSONRequestSerializer serializer]
     http：[AFHTTPRequestSerializer serializer]
     */
//    AFJSONRequestSerializer *request = [AFJSONRequestSerializer serializer];

    AFHTTPRequestSerializer *request = [AFHTTPRequestSerializer serializer];
    [WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer = request;
    /*! 设置apikey ------类似于自己应用中的tokken---此处仅仅作为测试使用*/
//            [manager.requestSerializer setValue:apikey forHTTPHeaderField:@"apikey"];
    
    /*! 复杂的参数类型 需要使用json传值-设置请求内容的类型*/
    //        [manager.requestSerializer setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    
    [[WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer setValue:@"application/x-www-form-urlencoded; application/json; application/javascript; application/x-javascript; charset=utf-8;" forHTTPHeaderField:@"Content-Type"];
    
    /*! 设置响应数据的基本类型 */
    [WCYNetworkManager sharedNetworkManager].sessionManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/json", @"text/javascript", @"text/html", @"text/css", @"text/xml", @"text/plain", @"application/javascript",@"application/x-javascript", @"application/x-www-form-urlencoded", @"image/*", nil];

    // 配置自建证书的Https请求
    [self setupSecurityPolicy];
}

/// 配置自建证书的Https请求，只需要将CA证书文件放入根目录就行
+ (void)setupSecurityPolicy {
    NSSet <NSData *> *cerSet = [AFSecurityPolicy certificatesInBundle:[NSBundle mainBundle]];
    if (cerSet.count == 0) {
        /*!
         采用默认的defaultPolicy就可以了. AFN默认的securityPolicy就是它, 不必另写代码. AFSecurityPolicy类中会调用苹果security.framework的机制去自行验证本次请求服务端放回的证书是否是经过正规签名.
         */
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy defaultPolicy];
        securityPolicy.allowInvalidCertificates = YES;
        securityPolicy.validatesDomainName = NO;
        [WCYNetworkManager sharedNetworkManager].sessionManager.securityPolicy = securityPolicy;
    } else {
        /*! 自定义的CA证书配置如下： */
        /*! 自定义security policy, 先前确保你的自定义CA证书已放入工程Bundle */
        /*!
         https://api.github.com网址的证书实际上是正规CADigiCert签发的, 这里把Charles的CA根证书导入系统并设为信任后, 把Charles设为该网址的SSL Proxy (相当于"中间人"), 这样通过代理访问服务器返回将是由Charles伪CA签发的证书.
         */
        // 使用证书验证模式
        AFSecurityPolicy *securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:cerSet];
        // 如果需要验证自建证书(无效证书)，需要设置为YES
        securityPolicy.allowInvalidCertificates = YES;
        // 是否需要验证域名，默认为YES
        //    securityPolicy.pinnedCertificates = [[NSSet alloc] initWithObjects:cerData, nil];
        
        [WCYNetworkManager sharedNetworkManager].sessionManager.securityPolicy = securityPolicy;
        
        /*! 如果服务端使用的是正规CA签发的证书, 那么以下几行就可去掉: */
        //            NSSet <NSData *> *cerSet = [AFSecurityPolicy certificatesInBundle:[NSBundle mainBundle]];
        //            AFSecurityPolicy *policy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeCertificate withPinnedCertificates:cerSet];
        //            policy.allowInvalidCertificates = YES;
        //            [WCYNetworkManager sharedNetworkManager].sessionManager.securityPolicy = policy;
    }
}

#pragma mark - 网络请求的类方法 --- get / post / put / delete

/// 网络请求的实例方法
/// @param type 请求类型get / post / put / delete
/// @param entity 请求实体 接口地址、参数等
/// @param successBlock 请求成功的回调
/// @param failureBlock 请求失败的回调
+ (WCYURLSessionTask *)requestWithType:(WCYHttpRequestType)type
                                entity:(WCYRequestEntity *)entity
                          successBlock:(WCYResponseSuccessBlock)successBlock
                          failureBlock:(WCYResponseFailBlock)failureBlock {
    if (entity.urlString == nil) {
        return nil;
    }
    
    WCYWeak;
    /*! 检查地址中是否有中文 */
    NSString *URLString = [NSURL URLWithString:entity.urlString] ? entity.urlString : [self strUTF8Encoding:entity.urlString];
    
    NSString *requestType;
    switch (type) {
        case 0:
            requestType = @"GET";
            break;
        case 1:
            requestType = @"POST";
            break;
        case 2:
            requestType = @"PUT";
            break;
        case 3:
            requestType = @"DELETE";
            break;
            
        default:
            break;
    }
    
    AFHTTPSessionManager *scc = [WCYNetworkManager sharedNetworkManager].sessionManager;
    AFHTTPResponseSerializer *scc2 = scc.responseSerializer;
    AFHTTPRequestSerializer *scc3 = scc.requestSerializer;
    NSTimeInterval timeoutInterval = [WCYNetworkManager sharedNetworkManager].timeoutInterval;
    
    NSString *isCache = entity.isNeedCache ? @"开启":@"关闭";
    CGFloat allCacheSize = [WCYNetworkCache wcy_getAllHttpCacheSize];
    
    if ([WCYNetworkManager sharedNetworkManager].isOpenLog) {
        NSLog(@"\n******************** 请求参数 ***************************");
        NSLog(@"\n请求头: %@\n超时时间设置：%.1f 秒【默认：30秒】\nAFHTTPResponseSerializer：%@【默认：AFHTTPResponseSerializer】\nAFHTTPRequestSerializer：%@【默认：AFHTTPRequestSerializer】\n请求方式: %@\n请求URL: %@\n请求param: %@\n是否启用缓存：%@【默认：开启】\n目前总缓存大小：%.6fM\n", [WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer.HTTPRequestHeaders, timeoutInterval, scc2, scc3, requestType, URLString, entity.parameters, isCache, allCacheSize);
        NSLog(@"\n********************************************************");
    }

    WCYURLSessionTask *sessionTask = nil;
    
    // 读取缓存
    id responseCacheData = [WCYNetworkCache wcy_httpCacheWithUrlString:entity.urlString parameters:entity.parameters];
    
    if (entity.isNeedCache && responseCacheData != nil) {
        if (successBlock) {
            successBlock(responseCacheData);
        }
        if ([WCYNetworkManager sharedNetworkManager].isOpenLog) {
            NSLog(@"取用缓存数据结果： *** %@", responseCacheData);
        }
        [[weakSelf tasks] removeObject:sessionTask];
        return nil;
    }
    
    if (entity.isSetQueryStringSerialization) {
        [[WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer setQueryStringSerializationWithBlock:^NSString * _Nonnull(NSURLRequest * _Nonnull request, id  _Nonnull parameters, NSError * _Nullable __autoreleasing * _Nullable error) {
            
            return parameters;
            
        }];
    }
    
    if (type == WCYHttpRequestTypeGet) {
        sessionTask = [[WCYNetworkManager sharedNetworkManager].sessionManager GET:URLString parameters:entity.parameters headers:entity.headers progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock) {
                successBlock(responseObject);
            }
            // 对数据进行异步缓存
            [WCYNetworkCache wcy_setHttpCache:responseObject urlString:entity.urlString parameters:entity.parameters];
            [[weakSelf tasks] removeObject:sessionTask];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            
            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf tasks] removeObject:sessionTask];
            
        }];
    } else if (type == WCYHttpRequestTypePost) {
        sessionTask = [[WCYNetworkManager sharedNetworkManager].sessionManager POST:URLString parameters:entity.parameters headers:entity.headers progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            if ([WCYNetworkManager sharedNetworkManager].isOpenLog) {
                NSLog(@"post 请求数据结果： *** %@", responseObject);
            }
            if (successBlock) {
                successBlock(responseObject);
            }
            
            // 对数据进行异步缓存
            [WCYNetworkCache wcy_setHttpCache:responseObject urlString:entity.urlString parameters:entity.parameters];
            [[weakSelf tasks] removeObject:sessionTask];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"错误信息：%@",error);

            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf tasks] removeObject:sessionTask];
            
        }];
    } else if (type == WCYHttpRequestTypePut) {
        sessionTask = [[WCYNetworkManager sharedNetworkManager].sessionManager PUT:URLString parameters:entity.parameters headers:entity.headers success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            
            if (successBlock) {
                successBlock(responseObject);
            }
            
            [[weakSelf tasks] removeObject:sessionTask];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"错误信息：%@",error);
            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf tasks] removeObject:sessionTask];
            
        }];
    } else if (type == WCYHttpRequestTypeDelete) {
        sessionTask = [[WCYNetworkManager sharedNetworkManager].sessionManager DELETE:URLString parameters:entity.parameters headers:entity.headers success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            if (successBlock) {
                successBlock(responseObject);
            }
            
            [[weakSelf tasks] removeObject:sessionTask];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"错误信息：%@",error);
            if (failureBlock) {
                failureBlock(error);
            }
            [[weakSelf tasks] removeObject:sessionTask];
            
        }];
    }
    
    if (sessionTask) {
        [[weakSelf tasks] addObject:sessionTask];
    }
    
    return sessionTask;
}

#pragma mark - 网络请求的类方法 + Entity --- get / post / put / delete
+ (WCYURLSessionTask *)request_GETWithEntity:(WCYRequestEntity *)entity successBlock:(WCYResponseSuccessBlock)successBlock failureBlock:(WCYResponseFailBlock)failureBlock {
    if (!entity || ![entity isKindOfClass:[WCYRequestEntity class]]) {
        return nil;
    }
    return [self requestWithType:WCYHttpRequestTypeGet entity:entity successBlock:successBlock failureBlock:failureBlock];
}

+ (WCYURLSessionTask *)request_POSTWithEntity:(WCYRequestEntity *)entity successBlock:(WCYResponseSuccessBlock)successBlock failureBlock:(WCYResponseFailBlock)failureBlock {
    if (!entity || ![entity isKindOfClass:[WCYRequestEntity class]]) {
        return nil;
    }
    return [self requestWithType:WCYHttpRequestTypePost entity:entity successBlock:successBlock failureBlock:failureBlock];;
}

+ (WCYURLSessionTask *)request_PUTWithEntity:(WCYRequestEntity *)entity successBlock:(WCYResponseSuccessBlock)successBlock failureBlock:(WCYResponseFailBlock)failureBlock {
    if (!entity || ![entity isKindOfClass:[WCYRequestEntity class]]) {
        return nil;
    }
    return [self requestWithType:WCYHttpRequestTypePut entity:entity successBlock:successBlock failureBlock:failureBlock];
}

+ (WCYURLSessionTask *)request_DELETEWithEntity:(WCYRequestEntity *)entity successBlock:(WCYResponseSuccessBlock)successBlock failureBlock:(WCYResponseFailBlock)failureBlock {
    if (!entity || ![entity isKindOfClass:[WCYRequestEntity class]]) {
        return nil;
    }
    return [self requestWithType:WCYHttpRequestTypeDelete entity:entity successBlock:successBlock failureBlock:failureBlock];
}

#pragma mark - 网络状态监测
+ (void)wcy_startNetWorkMonitoringWithBlock:(WCYNetWorkStatusBlock)networkStatus {
    /*! 1.获得网络监控的管理者 */
    AFNetworkReachabilityManager *manager = [AFNetworkReachabilityManager sharedManager];
    /*! 当使用AF发送网络请求时,只要有网络操作,那么在状态栏(电池条)wifi符号旁边显示  菊花提示 */
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    /*! 2.设置网络状态改变后的处理 */
    [manager setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        /*! 当网络状态改变了, 就会调用这个block */
        switch (status) {
            case AFNetworkReachabilityStatusUnknown: {
                NSLog(@"未知网络");
                networkStatus ? networkStatus(WCYNetworkStatusUnknown) : nil;
            } break;
            case AFNetworkReachabilityStatusNotReachable: {
                NSLog(@"没有网络");
                networkStatus ? networkStatus(WCYNetworkStatusNotReachable) : nil;
            } break;
            case AFNetworkReachabilityStatusReachableViaWWAN: {
                NSLog(@"手机自带网络");
                networkStatus ? networkStatus(WCYNetworkStatusReachableViaWWAN) : nil;
            } break;
            case AFNetworkReachabilityStatusReachableViaWiFi: {
                NSLog(@"wifi 网络");
                networkStatus ? networkStatus(WCYNetworkStatusReachableViaWiFi) : nil;
            } break;
        }
    }];
    [manager startMonitoring];
}

#pragma mark - 取消 Http 请求
+ (void)wcy_cancelAllRequest {
    // 锁操作
    @synchronized(self) {
        [[self tasks] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            [task cancel];
        }];
        [[self tasks] removeAllObjects];
    }
}

+ (void)wcy_cancelRequestWithURL:(NSString *)URL {
    if (!URL) {
        return;
    }
    @synchronized (self) {
        [[self tasks] enumerateObjectsUsingBlock:^(NSURLSessionTask  *_Nonnull task, NSUInteger idx, BOOL * _Nonnull stop) {
            
            if ([task.currentRequest.URL.absoluteString hasPrefix:URL]) {
                [task cancel];
                [[self tasks] removeObject:task];
                *stop = YES;
            }
        }];
    }
}

#pragma mark - url 中文格式化
+ (NSString *)strUTF8Encoding:(NSString *)str {
    /*! ios9适配的话 打开第一个 */
    return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
}

#pragma mark - 自定义请求头
+ (void)wcy_setValue:(NSString *)value forHTTPHeaderKey:(NSString *)HTTPHeaderKey {
    [[WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer setValue:value forHTTPHeaderField:HTTPHeaderKey];
}

+ (void)wcy_clearAuthorizationHeader {
    [[WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer clearAuthorizationHeader];
}

#pragma mark - 清除缓存
- (void)wcy_clearAllHttpCache {
    [WCYNetworkCache wcy_clearAllHttpCache];
}

#pragma mark - setter / getter
/**
 存储着所有的请求task数组
 
 @return 存储着所有的请求task数组
 */
+ (NSMutableArray *)tasks {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        tasks = [[NSMutableArray alloc] init];
    });
    return tasks;
}

- (void)setTimeoutInterval:(NSTimeInterval)timeoutInterval {
    _timeoutInterval = timeoutInterval;
    [WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer.timeoutInterval = timeoutInterval;
}

- (void)setRequestSerializer:(WCYHttpRequestSerializerType)requestSerializer {
    _requestSerializer = requestSerializer;
    switch (requestSerializer) {
        case WCYHttpRequestSerializerTypeJSON: {
            [WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer = [AFJSONRequestSerializer serializer] ;
        } break;
        case WCYHttpRequestSerializerTypeHTTP: {
            [WCYNetworkManager sharedNetworkManager].sessionManager.requestSerializer = [AFHTTPRequestSerializer serializer] ;
        } break;
            
        default:
            break;
    }
}

- (void)setResponseSerializer:(WCYHttpResponseSerializerType)responseSerializer {
    _responseSerializer = responseSerializer;
    switch (responseSerializer) {
        case WCYHttpResponseSerializerTypeJSON: {
            [WCYNetworkManager sharedNetworkManager].sessionManager.responseSerializer = [AFJSONResponseSerializer serializer] ;
        } break;
        case WCYHttpResponseSerializerTypeHTTP: {
            [WCYNetworkManager sharedNetworkManager].sessionManager.responseSerializer = [AFHTTPResponseSerializer serializer] ;
        } break;
            
        default:
            break;
    }
}

- (void)setHttpHeaderFieldDictionary:(NSDictionary *)httpHeaderFieldDictionary {
    _httpHeaderFieldDictionary = httpHeaderFieldDictionary;
    if (![httpHeaderFieldDictionary isKindOfClass:[NSDictionary class]]) {
        NSLog(@"请求头数据有误，请检查！");
        return;
    }
    NSArray *keyArray = httpHeaderFieldDictionary.allKeys;
    if (keyArray.count <= 0) {
        NSLog(@"请求头数据有误，请检查！");
        return;
    }
    
    for (NSInteger i = 0; i < keyArray.count; i ++) {
        NSString *keyString = keyArray[i];
        NSString *valueString = httpHeaderFieldDictionary[keyString];
        [WCYNetworkManager wcy_setValue:valueString forHTTPHeaderKey:keyString];
    }
}

@end
