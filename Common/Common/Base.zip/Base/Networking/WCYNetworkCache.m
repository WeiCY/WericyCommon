//
//  WCYNetworkCache.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/4.
//

#import "WCYNetworkCache.h"

#if __has_include(<YYCache/YYCache.h>)
FOUNDATION_EXPORT double YYCacheVersionNumber;
FOUNDATION_EXPORT const unsigned char YYCacheVersionString[];
#import <YYCache/YYCache.h>
#else
#import "YYCache.h"
#endif


static NSString * const kWCYNetworkCache = @"WCYNetworkCache";
static  YYCache *_dataCache;

@implementation WCYNetworkCache

+ (void)initialize {
    _dataCache = [YYCache cacheWithName:kWCYNetworkCache];
}

+ (void)wcy_setHttpCache:(id)httpData
               urlString:(NSString *)urlString
              parameters:(NSDictionary *)parameters {
    NSString *cacheKey = [self wcy_cacheWithUrlString:urlString parameters:parameters];
    [_dataCache setObject:httpData forKey:cacheKey];
}

+ (id)wcy_httpCacheWithUrlString:(NSString *)urlString
                      parameters:(NSDictionary *)parameters {
    NSString *cacheKey = [self wcy_cacheWithUrlString:urlString parameters:parameters];
    return [_dataCache objectForKey:cacheKey];
}

+ (void)wcy_httpCacheWithUrlString:(NSString *)urlString parameters:(NSDictionary *)parameters block:(void (^)(id<NSCoding> _Nonnull))block {
    NSString *cacheKey = [self wcy_cacheWithUrlString:urlString parameters:parameters];
    [_dataCache objectForKey:cacheKey withBlock:^(NSString * _Nonnull key, id<NSCoding>  _Nonnull object) {
        dispatch_async(dispatch_get_main_queue(), ^{
            block(object);
        });
    }];
}

+ (NSString *)wcy_cacheWithUrlString:(NSString *)urlString
                          parameters:(NSDictionary *)parameters {
    if (!parameters) {
        return urlString;
    }
    if ([parameters isKindOfClass:[NSDictionary class]]) {
        NSData *cacheData = [NSJSONSerialization dataWithJSONObject:parameters options:0 error:nil];
        NSString *cacheString = [[NSString alloc] initWithData:cacheData encoding:NSUTF8StringEncoding];
        
        NSString *cacheKey = [NSString stringWithFormat:@"%@%@", urlString, cacheString];
        return cacheKey;
    }
    return nil;
}

#pragma mark - 缓存大小/清理
+ (CGFloat)wcy_getAllHttpCacheSize {
    return [_dataCache.diskCache totalCost]/1024.0/1024.0;
}

+ (void)wcy_clearAllHttpCache {
    [_dataCache.diskCache removeAllObjects];
}

@end
