//
//  WCYRequestEntity.h
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/5.
//

#import <Foundation/Foundation.h>

#define BASE_URL @"http://fund.eastmoney.com/js/jjjz_gs.js"

NS_ASSUME_NONNULL_BEGIN

/// 请求实体，承载请求参数
@interface WCYRequestEntity : NSObject

/** 请求路径 */
@property (nonatomic, copy) NSString *urlString;
/** 请求参数 */
@property (nonatomic, copy) id parameters;
/** 是否缓存响应 */
@property (nonatomic, assign, getter=isNeedCache) BOOL needCache;

/** 请求头， 适配新版本，可单独为接口设置请求头 */
@property(nonatomic, strong) NSDictionary *headers;

/** 将传入 的 string 参数序列化，body 请求 */
@property(nonatomic, assign) BOOL isSetQueryStringSerialization;


@end

NS_ASSUME_NONNULL_END
