//
//  WCYBaseWebViewController.h
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/2.
//

#import "WCYBaseViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface WCYBaseWebViewController : WCYBaseViewController

/// 网址
@property (nonatomic, strong) NSURL *url;

/// 进度条颜色
@property (nonatomic, strong) UIColor* progressColor;

/// 初始化
/// @param url 地址
- (instancetype)initWithUrl:(NSURL *)url;

/// 刷新页面
- (void)reloadWebView;

@end

NS_ASSUME_NONNULL_END
