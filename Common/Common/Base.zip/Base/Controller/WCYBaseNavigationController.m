//
//  WCYBaseNavigationController.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/1.
//

#import "WCYBaseNavigationController.h"
#import "WeicyCommon.h"
#import "WeicyCommonProjectCustom.h"

@interface WCYBaseNavigationController ()<UINavigationBarDelegate, UINavigationControllerDelegate>

@end

@implementation WCYBaseNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self changeBase];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - 初始化
- (instancetype)initWithRootViewController:(UIViewController *)rootViewController {
    if (self = [super initWithRootViewController:rootViewController]) {
        [self config];
    }
    return self;
}

- (instancetype)init {
    if (self = [super init]) {
        [self config];
    }
    return self;
}

- (void)config {
    self.modalPresentationStyle = UIModalPresentationFullScreen;
}


- (void) traitCollectionDidChange:(UITraitCollection *)previousTraitCollection
{
    [super traitCollectionDidChange:previousTraitCollection];
    
    UITraitCollection *traitCollection = [UITraitCollection currentTraitCollection];// 获取当前的TraitCollection
    BOOL hasUserInterfaceStyleChanged = [previousTraitCollection hasDifferentColorAppearanceComparedToTraitCollection:traitCollection];
    // 根据当前模式更新视图
    NSLog(@"%d",hasUserInterfaceStyleChanged);
    if (hasUserInterfaceStyleChanged) {
        [self changeBase];
    }
}


#pragma mark - UI
- (void)changeBase {
    self.navigationBar.barTintColor = Navi_Background_Color;

    [self.navigationBar setBackgroundImage:[UIImage weicy_imageWithColor:Navi_Background_Color size:CGSizeMake(kScreenW, kSTATUSBAR_NAVIGATION_HEIGHT)] forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:NaviBar_Font,NSForegroundColorAttributeName:NaviBar_Title_Color}];

    // 导航栏阴影
//    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated{
    
    if (self.childViewControllers.count > 0) {
        viewController.hidesBottomBarWhenPushed = YES;
        
        UIButton *backBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        backBtn.frame = CGRectMake(0, 0, 30, 30);
        [backBtn setImage:NaviBar_Back_Image forState:UIControlStateNormal];
        @weakify(self)
        [backBtn weicy_setBlockForControlEvents:UIControlEventTouchUpInside block:^(id  _Nonnull sender) {
            @strongify(self)
            [self popViewControllerAnimated:YES];
        }];
        viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    }
    [super pushViewController:viewController animated:animated];
}

@end
