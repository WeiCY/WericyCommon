//
//  WCYBaseWebViewController.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/2.
//

#import "WCYBaseWebViewController.h"
#import <WebKit/WebKit.h>
#import <JavaScriptCore/JavaScriptCore.h>

@interface WCYBaseWebViewController ()<WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler>

@property (nonatomic, strong) UIButton *backButton;
@property (nonatomic, strong) UIButton *closeButton;

@property (nonatomic, strong) WKWebView *webView;
@property (nonatomic, strong) CALayer *progresslayer;
//@property (nonatomic, strong) WebViewJavascriptBridge *bridge;

@end

@implementation WCYBaseWebViewController

#pragma mark - 生命周期
- (instancetype)initWithUrl:(NSURL *)url {
    if (self = [super init]) {
        self.url = url;
    }
    return self;
}

- (void)dealloc {
    [_webView removeObserver:self forKeyPath:@"title"];
    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
}

#pragma mark - 页面消失 清除缓存
- (void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self deleteWebCache];
}

- (void)deleteWebCache {
    NSSet *websiteDataTypes = [NSSet setWithArray:@[WKWebsiteDataTypeDiskCache,WKWebsiteDataTypeMemoryCache]];
    NSDate *dateFrom = [NSDate dateWithTimeIntervalSince1970:0];
    [[WKWebsiteDataStore defaultDataStore] removeDataOfTypes:websiteDataTypes modifiedSince:dateFrom completionHandler:^{
        
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

#pragma mark - 初始化
- (void)initUI {
    UIBarButtonItem *backBarItem = [[UIBarButtonItem alloc] initWithCustomView:self.backButton];
    UIBarButtonItem *closeBarItem = [[UIBarButtonItem alloc] initWithCustomView:self.closeButton];
    self.navigationItem.leftBarButtonItems = @[backBarItem, closeBarItem];
    
    [self.view addSubview:self.webView];
    [self.webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(UIEdgeInsetsMake(0, 0, 0, 0));
    }];
    [self.view.layer addSublayer:self.progresslayer];
}

- (void)initData {
    if (self.url) {
        [self.webView loadRequest:[NSURLRequest requestWithURL:self.url]];
        
//        NSString *token = CLoudEnjoyLocalData.token == nil ? @"" : CLoudEnjoyLocalData.token;
//        kWeakSelf(self);
//        [self.bridge callHandler:@"getToken" data:@{@"token": token} responseCallback:^(id responseData) {
//
//            NSLog(@"responseData --- %@", responseData);
//        }];
//
//        [self.bridge registerHandler:@"transferToken" handler:^(id data, WVJBResponseCallback responseCallback) {
//
//            //web 调用 oc
//            NSDictionary *transferData = @{@"token": token};
//            responseCallback(transferData);
//            NSLog(@"called: %@", data);
//
//        }];
//
//        [self.bridge registerHandler:@"colseWeb" handler:^(id data, WVJBResponseCallback responseCallback) {
//            [weakself closeClick];
//        }];
//
//        [self.bridge registerHandler:@"share" handler:^(id data, WVJBResponseCallback responseCallback) {
//            NSLog(@"closeWeb called: %@", data);
//            //            [weakself goToShare];
//        }];
//
//
//        [self.bridge registerHandler:@"jump" handler:^(id data, WVJBResponseCallback responseCallback) {
//            NSLog(@"==========拿到的数据=======%@", data);
//
//
//        }];
//
//        //跳转三方
//        [self.bridge registerHandler:@"linkTo" handler:^(id data, WVJBResponseCallback responseCallback) {
//
//            NSLog(@"closeWeb called: %@", data);
//
//            NSString *url = [NSString stringWithFormat:@"%@", data[@"url"]];
//            NSURL *openURL = [NSURL URLWithString:url];
//            [[UIApplication sharedApplication] openURL:openURL options:@{} completionHandler:^(BOOL success) {
//
//            }];
//
//        }];
    }
}

#pragma mark - setter
- (void)setProgressColor:(UIColor *)progressColor {
    _progressColor = progressColor;
    self.progresslayer.backgroundColor = progressColor.CGColor;
}

#pragma mark - 外漏方法
- (void)reloadWebView {
    [self.webView reload];
}

#pragma mark - WKNavigationDelegate
/*
 1 在请求发送之前，决定是否跳转
 2 页面开始加载时调用
 3 在收到响应后，决定是否跳转
 4 内容开始加载时调用
 5  接收到服务器跳转请求之后调用（不一定调用该方法）
 5 页面加载完成时调用
 6 请求失败时调用
 */

// 在请求发送之前，决定是否跳转 -> 该方法如果不实现，系统默认跳转。如果实现该方法，则需要设置允许跳转，不设置则报错。
// decisionHandler(WKNavigationActionPolicyAllow);
// 该方法执行在加载界面之前
// Terminating app due to uncaught exception 'NSInternalInconsistencyException', reason: 'Completion handler passed to -[ViewController webView:decidePolicyForNavigationAction:decisionHandler:] was not called'


// 在发送请求之前，决定是否跳转
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    NSLog(@"%@",navigationAction.request.URL.absoluteString);
    
    /*
     //允许跳转
     decisionHandler(WKNavigationActionPolicyAllow);
     
     //不允许跳转
     //    decisionHandler(WKNavigationActionPolicyCancel);
     NSLog(@"在请求发送之前，决定是否跳转。  1");
     */
    NSURL *URL = navigationAction.request.URL;
    NSString *scheme = [URL scheme];
    UIApplication *app = [UIApplication sharedApplication];
    
    // 打电话
    if ([scheme isEqualToString:@"tel"]) {
        if ([app canOpenURL:URL]) {
            [app openURL:URL options:@{} completionHandler:^(BOOL success) {
                
            }];
            // 一定要加上这句,否则会打开新页面
            decisionHandler(WKNavigationActionPolicyCancel);
            return;
        }
    } else if ([navigationAction.request.URL.absoluteString containsString:@"untitled.html"]) {
        // 如果是特定的url 需要进行设置
        decisionHandler(WKNavigationActionPolicyCancel);
    } else {
        if (navigationAction.targetFrame == nil) {
            [webView loadRequest:navigationAction.request];
        }
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

// 页面开始加载时调用
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    NSLog(@"页面开始加载时调用。   2");
}

// 页面加载完成时调用
- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"页面加载完成时调用。 5");
}

// 请求失败时调用
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"error1:%@",error);
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSLog(@"error2:%@",error);
}

//内容返回时调用，得到请求内容时调用(内容开始加载) -> view的过渡动画可在此方法中加载
- (void)webView:(WKWebView *)webView didCommitNavigation:( WKNavigation *)navigation {
    NSLog(@"内容返回时调用，得到请求内容时调用。 4");
}

// 在收到响应后，决定是否跳转（同上）
// 该方法执行在内容返回之前
- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    //允许跳转
    decisionHandler(WKNavigationResponsePolicyAllow);
    //不允许跳转
    //    decisionHandler(WKNavigationResponsePolicyCancel);
    NSLog(@"在收到响应后，决定是否跳转。 3");
    
}

// 接收到服务器跳转请求之后调用
- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(null_unspecified WKNavigation *)navigation {
    NSLog(@"接收到服务器跳转请求之后调用 不一定有");
}

-(void)webViewWebContentProcessDidTerminate:(WKWebView *)webView {
    NSLog(@"webViewWebContentProcessDidTerminate");
}

#pragma mark - WKScriptMessageHandler
//WKScriptMessageHandler协议方法
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message {
    // 收到 js的交互
    // 需要在 configuration生成是注册 这种方法message.body必填
}

#pragma mark - WKUIDelegate
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(void))completionHandler {
    // js 里面的alert实现，如果不实现，网页的alert函数无效

}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    //  js 里面的alert实现，如果不实现，网页的alert函数无效  ,
}

#pragma mark - observe
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSKeyValueChangeKey,id> *)change context:(void *)context{
    
    if ([keyPath isEqualToString:@"estimatedProgress"]) {
        self.progresslayer.opacity = 1;
        float floatNum = [[change objectForKey:@"new"] floatValue];
        self.progresslayer.frame = CGRectMake(0, 0, kScreenW * floatNum, 2);
        if (floatNum == 1) {
            
            __weak __typeof(self)weakSelf = self;
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                weakSelf.progresslayer.opacity = 0;
                
            });
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                
                weakSelf.progresslayer.frame = CGRectMake(0, 0, 0, 3);
            });
        }
        
    }  else if ([keyPath isEqualToString:@"title"]) {
        self.navigationItem.title = [change objectForKey:@"new"];
    } else {
        [super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
    }
    
}


#pragma mark - 懒加载
- (UIButton *)backButton {
    if (!_backButton) {
        _backButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _backButton.frame = CGRectMake(0, 0, 34, 34);
        [_backButton setImage:NaviBar_Back_Image forState:UIControlStateNormal];
        @weakify(self);
        [_backButton weicy_setBlockForControlEvents:UIControlEventTouchUpInside block:^(id  _Nonnull sender) {
            @strongify(self);
            if ([self.webView canGoBack]) {
                [self.webView goBack];
            } else {
                [self.navigationController popViewControllerAnimated:YES];
            }
        }];
    }
    return _backButton;
}

- (UIButton *)closeButton {
    if (!_closeButton) {
        _closeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _closeButton.frame = CGRectMake(0, 0, 34, 34);
        [_closeButton setImage:NaviBar_Web_Close_Black_Image forState:UIControlStateNormal];
        @weakify(self);
        [_closeButton weicy_setBlockForControlEvents:UIControlEventTouchUpInside block:^(id  _Nonnull sender) {
            @strongify(self);
            [self.navigationController popViewControllerAnimated:YES];
        }];
    }
    return _closeButton;
}

- (WKWebView *)webView {
    if (!_webView) {
        // js配置
        WKUserContentController *userContentController = [[WKUserContentController alloc] init];
        // WKWebView的配置
        WKWebViewConfiguration *configuration = [[WKWebViewConfiguration alloc] init];
        configuration.userContentController = userContentController;
        configuration.allowsInlineMediaPlayback = YES;
        configuration.preferences = [WKPreferences new];
        /*
         // 需要将被js调用的方法注册进去 这是使用系统的方法 也可以使用WebViewJavascriptBridge 三方库
         [configuration.userContentController addScriptMessageHandler:self name:@"selectWayPay"];
         [configuration.userContentController addScriptMessageHandler:self name:@"ios_logIn"];
         */
        
        _webView = [[WKWebView alloc]initWithFrame:CGRectZero configuration:configuration];
        _webView.navigationDelegate = self;
        _webView.UIDelegate = self;
        [_webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:nil];
        [_webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
    }
    return _webView;
}

- (CALayer *)progresslayer {
    if (!_progresslayer) {
        _progresslayer = [[CALayer alloc] init];
        _progresslayer.frame = CGRectMake(0, 0, 0, 2);
        _progresslayer.backgroundColor = WEB_PROGRESS_COLOR.CGColor;
    }
    return _progresslayer;
}

//- (WebViewJavascriptBridge *)bridge {
//    
//    if (!_bridge) {
//        _bridge = [WebViewJavascriptBridge bridgeForWebView:self.webView showJSconsole:YES enableLogging:YES];
//    }
//    return _bridge;
//}

@end
