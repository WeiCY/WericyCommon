//
//  WCYBaseTabBarViewController.m
//  WcyFund
//
//  Created by CityDoWCY on 2021/1/1.
//

#import "WCYBaseTabBarViewController.h"
//#import "WCYBaseNavigationController.h"
#import "WeicyCommonProjectCustom.h"

#import "HomeViewController.h"
#import "MineViewController.h"

#import "RTRootNavigationController.h"

@interface WCYBaseTabBarViewController ()

@end

@implementation WCYBaseTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self baseTabBar];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (void)baseTabBar {
    self.tabBar.shadowImage = [UIImage new];
    self.tabBar.backgroundImage = [UIImage new];
    [[UITabBar appearance]setBackgroundColor:TabBar_Background_Color];
    if (@available(iOS 13.0, *)) { // 解决IOS13 tabbar 字体变成蓝色问题

        [[UITabBar appearance] setUnselectedItemTintColor:TabBar_Normal_Color];

    }
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, -0.5, kScreenW, 0.5)];
    view.backgroundColor = TabBar_SepLine_Color;
    [[UITabBar appearance] insertSubview:view atIndex:0];
    [self setupChildControllers];
}

- (void)setupChildControllers {
    
    HomeViewController *vc1 = [HomeViewController new];
    MineViewController *vc2 = [MineViewController new];
    [self creatOneChildVc:vc1 title:@"主页" image:@"ic_tab_order_nor" selectedImage:@"ic_tab_order_sel"];
    [self creatOneChildVc:vc2 title:@"我的" image:@"ic_tab_mine_nor" selectedImage:@"ic_tab_mine_sel"];
}

- (void)creatOneChildVc:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage {
    vc.title = title;
    UIImage *img = [UIImage imageNamed:image];
    img = [img imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    UIImage *selImage = [UIImage imageNamed:selectedImage ];
    selImage = [selImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    
    NSDictionary *dictNormal = @{NSForegroundColorAttributeName:TabBar_Normal_Color,
                                 NSFontAttributeName:TabBar_Normal_Font};
    
    NSDictionary *dictSelected = @{NSForegroundColorAttributeName:TabBar_Selected_Color,
                                   NSFontAttributeName: TabBar_Selected_Font};
    
//    WCYBaseNavigationController *nav = [[WCYBaseNavigationController alloc] initWithRootViewController:vc];
//    nav.tabBarItem.title = title;
//    nav.tabBarItem.image = img;
//    nav.tabBarItem.selectedImage = selImage;
//    [nav.tabBarItem setTitleTextAttributes:dictNormal forState:UIControlStateNormal];
//    [nav.tabBarItem setTitleTextAttributes:dictSelected forState:UIControlStateSelected];
//    [self addChildViewController:nav];
    
    RTRootNavigationController *nav = [[RTRootNavigationController alloc] initWithRootViewController:vc];
    nav.tabBarItem.title = title;
    nav.tabBarItem.image = img;
    nav.tabBarItem.selectedImage = selImage;
    [nav.tabBarItem setTitleTextAttributes:dictNormal forState:UIControlStateNormal];
    [nav.tabBarItem setTitleTextAttributes:dictSelected forState:UIControlStateSelected];
    [self addChildViewController:nav];
    
}

@end
