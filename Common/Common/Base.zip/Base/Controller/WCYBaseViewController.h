//
//  WCYBaseViewController.h
//  WcyFund
//
//  Created by CityDoWCY on 2020/12/31.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

/*
 * 控制器基类
 * 头部暴露的方法分两类：
    1.可以被调用的方法；
    2.生命周期方法(用法类似viewDidLoad这种)，子类只需要实现之。
 * 当前功能列表:
    1. 处理网络状态变化
    2. 处理屏幕旋转 （iPad应用中非常有用）
    3. 便捷调用HUD
    4. 应用内国际化
    5. 页面留存打点 （比如UMENG）
    6. 处理全局的通知，比如账号被T出（当前处在任意的页面，这种情况一般都是从server端收到的通知），自动退回到登陆页
    7. 应用主题设置，全局修改主题（这里用背景色做演示）
 * 宗旨：全局性viewcontroller可以共有的且应该属于viewcontroller处理范畴内的任务，放到基类来做。
 *  TODO: router方案：自动注册基类，处理url跳转等。 （此处内容较多，demo未实现） 参考：UMViewController，https://github.com/gaosboy/urlmanager
 *  TODO: 通知工具类的导入。不用再写移除通知方法
 */
@interface WCYBaseViewController : UIViewController

#pragma mark - 可被调用的方法
- (void)initUI;
- (void)initData;

// 可以自定义提示 最好是都在这里面统一修改 方便整体统一
// TODO:后期考虑添加几个不同状态 例如成功失败显示不同
- (void)showHUD;
- (void)showHUDWithText:(NSString *)text;
- (void)hideHUD;
- (void)hideHUDWithText:(NSString *)text;

#pragma mark - 子类实现的方法（不能直接调用）

//// 若需要子类调用super的方法，可以在后面加上NS_REQUIRES_SUPER
//// 例：- (void)foo NS_REQUIRES_SUPER;
//// virtual, for subclass override
//- (void)changeConstraintsToLandscape:(UIInterfaceOrientation)orient;
//// virtual, for subclass override
//- (void)changeConstraintsToPortrait:(UIInterfaceOrientation)orient;
//// virtual, for subclass override
//- (void)handleNetworkStatus:(BOOL)isAvailable;
//
//- (void)reloadUIForGlobal NS_REQUIRES_SUPER;
//
//- (void)reloadUIForTheme:(CustomThemeType)theme NS_REQUIRES_SUPER;
//
//// 子类可以不重写此方法（默认行为退回到login页）。
//- (void)backToLogin;


@end

NS_ASSUME_NONNULL_END
