//
//  WCYBaseViewController.m
//  WcyFund
//
//  Created by CityDoWCY on 2020/12/31.
//

#import "WCYBaseViewController.h"

#import "UINavigationController+FDFullscreenPopGesture.h"
#import "RTRootNavigationController.h"

#import "WeicyCommon.h"
#import "WeicyCommonProjectCustom.h"

@interface WCYBaseViewController ()

@end

@implementation WCYBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self basicCode];
    [self initCustomNoti];
    [self initUI];
    [self initData];
    // Do any additional setup after loading the view.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - 基本操作
- (void)basicCode {
    //背景颜色
    
    self.view.backgroundColor = VIEW_BG_COLOR;
    [self initCustomNavi];
    //添加单击手势
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endEditingAction)];
    tapGesture.cancelsTouchesInView = NO;
    tapGesture.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tapGesture];
}

#pragma mark - 自定义导航栏
- (void)initCustomNavi {
    self.navigationController.navigationBar.barTintColor = Navi_Background_Color;
    [self.navigationController.navigationBar setBackgroundImage:[UIImage weicy_imageWithColor:Navi_Background_Color size:CGSizeMake(kScreenW, kSTATUSBAR_NAVIGATION_HEIGHT)] forBarMetrics:UIBarMetricsDefault];
    [[UINavigationBar appearance] setTitleTextAttributes:@{NSFontAttributeName:NaviBar_Font,NSForegroundColorAttributeName:NaviBar_Title_Color}];

    // 导航栏阴影
//    [[UINavigationBar appearance] setShadowImage:[[UIImage alloc] init]];
}
- (UIBarButtonItem *)rt_customBackItemWithTarget:(id)target action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setImage:NaviBar_Back_Image forState:UIControlStateNormal];
    [button sizeToFit];
    [button addTarget:target
               action:action
     forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:button];
}

#pragma mark - 可选操作
- (void)initCustomNoti {
//    // 应用内国际化
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(languageChanged:)
//                                                 name:LanguageChangedNotification
//                                               object:nil];
//
//    // 应用主题设置
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(themeChanged:)
//                                                 name:ThemeChangedNotification
//                                               object:nil];
    // 网络变化
}

#pragma mark - Private Methods
//页面空白处点击，停止编辑
- (void)endEditingAction {
    [self.view endEditing:YES];
}

- (void)languageChanged:(NSNotification *)notification
{
//    [self reloadUIForGlobal];
}

- (void)themeChanged:(NSNotification *)notification
{
//    CustomThemeType themeType = [notification.object integerValue];
//    [self reloadUIForTheme:themeType];
}

//// implement this method to support ios7 either.
//- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
//    if (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft || toInterfaceOrientation == UIInterfaceOrientationLandscapeRight) {
//        [self changeConstraintsToLandscape:toInterfaceOrientation];
//    } else {
//        [self changeConstraintsToPortrait:toInterfaceOrientation];
//    }
//}
//
//- (void)networkChanged:(NSNotification *)notification {
//    LocalConnection *lc = (LocalConnection *)notification.object;
//    BOOL isNetworkAvailable = [lc isReachable];
//
//    [self handleNetworkStatus:isNetworkAvailable];
//}

//  1. 处理网络状态变化
- (void)handleNetworkStatus:(BOOL)isAvailable
{
    // virtual, for subclass override
}

#pragma mark - 生命周期
// 可在这里面进行埋点操作
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // 主题操作
//    NSString *themeString = [[NSUserDefaults standardUserDefaults] stringForKey:@"Theme"];
//    if ([themeString length] > 0) {
//        [self reloadUIForTheme:[themeString integerValue]];
//    }
    
//    // 国际化
//    // 这里的麻烦之处在于IB的国际化；我们并未生成2个不同的IB文件，因此需要刷新一些值的内容；所以在这里有这个方法调用。
//    [self reloadUIForGlobal];
    
    // 页面进入时也要根据屏幕方向调整相关布局。
//    UIInterfaceOrientation currentOrientation = [UIApplication sharedApplication].statusBarOrientation;
//    if (currentOrientation == UIInterfaceOrientationLandscapeLeft || currentOrientation == UIInterfaceOrientationLandscapeRight) {
//        [self changeConstraintsToLandscape:currentOrientation];
//    } else {
//        [self changeConstraintsToPortrait:currentOrientation];
//    }
    
    // 网络变化
//    BOOL isNetworkAvailable = [GLocalConnection isReachable];
//    if (!isNetworkAvailable)
//    {
//        // 页面进入时若网络不可用则也触发此方法。
//        [self handleNetworkStatus:isNetworkAvailable];
//    }
//
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(networkChanged:)
//                                                 name:kLocalConnectionChangedNotification
//                                               object:nil];
//
//    // 全局强制登录通知
//    [[NSNotificationCenter defaultCenter] addObserver:self
//                                             selector:@selector(forceLogout:)
//                                                 name:ForceLogoutNotification
//                                               object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    // 页面埋点
    // 移除通知
    
    // 页面退出时隐藏HUD
    [self hideHUD];
}


- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NSLog(@"%@ 销毁",self);
}

#pragma mark - 内存错误
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    NSLog(@"%@",@"内存警告");
}

#pragma mark - 可被调用的方法
- (void)initUI {
    
}

- (void)initData {
    
}

- (void)showHUD {
    [self.view makeToast:@"加载中"];
    // 使用三方MBProgressHUD
//    if (self.innerHUD == nil)
//    {
//        self.innerHUD = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
//        self.innerHUD.userInteractionEnabled = NO;
//        self.innerHUD.mode = MBProgressHUDModeCustomView;
//    }
}

- (void)showHUDWithText:(NSString *)text {
    [self.view makeToast:text];
//    [self showHUD];
//    self.innerHUD.label.text = text;
}

- (void)hideHUD {
    [self.view hideToast];
//    [self.innerHUD hideAnimated:NO];
//    self.innerHUD = nil;
}

- (void)hideHUDWithText:(NSString *)text {
    [self.view makeToast:text];
    kGCD_after(1.0, ^{
        [self hideHUD];
    });
//    self.innerHUD.label.text = text;
//    [self.innerHUD hideAnimated:NO afterDelay:1.0f];
//    self.innerHUD = nil;
}

#pragma mark - 子类实现的方法（不能直接调用）
- (void)reloadUIForGlobal NS_REQUIRES_SUPER {
   // 基类若存在需要国际化的UI部分，可以在此处处理。
}

//- (void)reloadUIForTheme:(CustomThemeType)theme NS_REQUIRES_SUPER {
//    // 基类若存在主题相关的UI部分，可以在此处处理。
//}

//  2. 处理屏幕旋转
- (void)changeConstraintsToLandscape:(UIInterfaceOrientation)orient {
    // virtual, for subclass override
}

- (void)changeConstraintsToPortrait:(UIInterfaceOrientation)orient {
    // virtual, for subclass override
}

@end
